// 상속없이 동일한 기능 만들기
public class DMBCellphone2 {
  // Cellphone + DMBCellphone 필드 합치면 됨
}
