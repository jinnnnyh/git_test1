public class StudentEx {
  public static void main(String[] args) {
    Student student = new Student("박성호", "555-555",1);
    System.out.println("이름 : " + student.name);
    System.out.println("ssn : " + student.ssn);
    System.out.println("studentNo : " + student.studentNo);

  }
}
